package com.flowable.control;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtDecoders;

import com.flowable.control.logic.constant.ControlPrivileges;

public class FlowableControlOAuth2UserService implements OAuth2UserService<OidcUserRequest, OidcUser> {

	private static final Logger log = LoggerFactory.getLogger(OAuth2SecurityConfiguration.class);
	
	private static final String ATTRIBUTE_PREFERRED_USERNAME = "preferred_username";

    @Override
    public OidcUser loadUser(OidcUserRequest userRequest) throws OAuth2AuthenticationException {
        // check if token has permissions to use Flowable Control
        boolean userHasPermissionsToAccessFlowableControl = true;
        
        log.info("************** FlowableControlOAuth2UserService ************** ");
        
        log.info("************** " + userRequest.getIdToken().getEmail());
        log.info("************** " + userRequest.getIdToken().getFullName());
        
        String tokenValue = userRequest.getAccessToken().getTokenValue();
        log.info("************** " + tokenValue);  
        log.info("************** " + userRequest.getAccessToken().getScopes());
        
        if (!userHasPermissionsToAccessFlowableControl) {
            throw new OAuth2AuthenticationException(
                    new OAuth2Error("001", userRequest.getIdToken().getClaimAsString(ATTRIBUTE_PREFERRED_USERNAME) + " is not authorized", null)
            );
        }
        JwtDecoder jwtDecoder = JwtDecoders.fromOidcIssuerLocation(userRequest.getIdToken().getIssuer().toString());
        
        Jwt jwt = jwtDecoder.decode(tokenValue);
        
        log.info("************** " + jwt.getClaimAsStringList("realm_access"));
        
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ACCESS_CONTROL));
		grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ACCESS_ADMIN));
		grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ADMIN));
		grantedAuthorities.add(new SimpleGrantedAuthority("report-api"));
		grantedAuthorities.add(new SimpleGrantedAuthority("access-report-api"));
		grantedAuthorities.add(new SimpleGrantedAuthority("reports"));
		grantedAuthorities.add(new SimpleGrantedAuthority("access-reports"));
		grantedAuthorities.add(new SimpleGrantedAuthority("case-instances"));
		grantedAuthorities.add(new SimpleGrantedAuthority("access-case-instances"));
		grantedAuthorities.add(new SimpleGrantedAuthority("process-instances"));
		grantedAuthorities.add(new SimpleGrantedAuthority("access-process-instances"));
		return new ControlOidcUser(grantedAuthorities, userRequest.getIdToken());
         
        /*
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ACCESS_CONTROL));
        grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ACCESS_ADMIN));
        grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ADMIN));
        return new DefaultOidcUser(grantedAuthorities, userRequest.getIdToken());
        */
    }

}
