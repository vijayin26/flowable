package com.flowable.control;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlowableCtrlApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlowableCtrlApplication.class, args);
	}

}
