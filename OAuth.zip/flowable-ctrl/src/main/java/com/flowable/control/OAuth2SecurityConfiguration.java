package com.flowable.control;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.header.writers.XXssProtectionHeaderWriter;

import com.flowable.control.logic.constant.ControlPrivileges;

@Order(2)
@EnableWebSecurity
public class OAuth2SecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	private static final Logger log = LoggerFactory.getLogger(OAuth2SecurityConfiguration.class);

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        
    	log.info("************** OAuth2SecurityConfiguration ************** ");
    	
    	http
                .csrf()
                .disable()
                .headers()
                .frameOptions()
                .sameOrigin()
                .addHeaderWriter(new XXssProtectionHeaderWriter())
                .and()
                .authorizeRequests()
                .antMatchers("/**").hasAuthority(ControlPrivileges.ACCESS_CONTROL)
                .and()
                .oauth2Login()
                .userInfoEndpoint()
                .oidcUserService(new FlowableControlOAuth2UserService());
    }

}
