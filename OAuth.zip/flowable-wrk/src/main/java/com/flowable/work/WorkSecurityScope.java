package com.flowable.work;
/*
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import com.flowable.core.common.api.security.SecurityScope;

public class WorkSecurityScope implements SecurityScope {

    protected Authentication authentication;

    public WorkSecurityScope(Authentication authentication) {
        this.authentication = authentication;
    }

    @Override
    public String getUserId() {
        return authentication.getName();
    }

    @Override
    public Set<String> getGroupKeys() {
        Set<String> groupKeys = new HashSet<>();
        for (GrantedAuthority authority: authentication.getGrantedAuthorities()) {
            if (authority instanceof GroupGrantedAuthority) {
                groupKeys.add(((GroupGrantedAuthority) authority).getGroupId());
            }
        }
        return groupKeys;
    }

    @Override
    public String getTenantId() {
        return getWorkUserDetails().getTenantId();
    }

    @Override
    public String getUserDefinitionKey() {
        // If you need you can do a mapping between certain attributes from your
        // user details to a Flowable User Definition
        return null;
    }

    @Override
    public boolean hasAuthority(String authority) {
        for (GrantedAuthority grantedAuthority : authentication.getAuthorities()) {
            if (Objects.equals(authority, grantedAuthority.getAuthority())) {
                return true;
            }
        }

        return false;
    }

    protected WorkUserDetails getWorkUserDetails() {
        return (WorkUserDetails) authentication.getDetails();
    }
}
*/