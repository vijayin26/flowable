package com.flowable.work;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

@RestController
public class SwaggerController {

    private static final Logger LOG = LoggerFactory.getLogger(SwaggerController.class);

    private static final String RESOURCE_BASE_PATH = "/swagger/";
    private static final String RESOURCE_SUFFIX = ".yml";

    private final ObjectMapper objectMapper = new ObjectMapper(new YAMLFactory());
    private final ResourcePatternResolver resourcePatternResolver;
    private final Environment environment;

    @Autowired
    public SwaggerController(ResourcePatternResolver resourcePatternResolver, Environment environment) {
        this.resourcePatternResolver = resourcePatternResolver;
        this.environment = environment;
    }

    @GetMapping("/swagger-resources")
    public List<SwaggerResource> getResourceList() {
        List<SwaggerResource> swaggerResources = new ArrayList<>();
        try {
            Resource[] resources = resourcePatternResolver.getResources("classpath:" + RESOURCE_BASE_PATH + "*" + RESOURCE_SUFFIX);
            for (Resource resource : resources) {
                Map<String, Object> swaggerDoc = getSwaggerDocAsMap(resource);
                String resourcePath = "/swagger-resources/" + resource.getFilename();
                swaggerResources.add(new SwaggerResource(
                        readPropertyNullSafe(swaggerDoc, "info", "title"),
                        resourcePath,
                        readPropertyNullSafe(swaggerDoc, "swagger"),
                        resourcePath
                ));
            }
        } catch (IOException e) {
            LOG.error("Failed to load swagger resources", e);
        }
        return swaggerResources;
    }

    @GetMapping(value = "/swagger-resources/{identifier}" + RESOURCE_SUFFIX, produces = {"text/vnd.yaml", "text/yaml"})
    public String getResourceFile(@PathVariable String identifier) throws JsonProcessingException {
        String swaggerResourceFilename = RESOURCE_BASE_PATH + FilenameUtils.getBaseName(identifier) + RESOURCE_SUFFIX;
        Map<String, Object> swaggerDoc = getSwaggerDocAsMap(new ClassPathResource(swaggerResourceFilename));
        swaggerDoc.put("host", "localhost:" + environment.getProperty("local.server.port"));
        swaggerDoc.put("basePath", "/" + identifier + "-api");
        return objectMapper.writeValueAsString(swaggerDoc);
    }

    @SuppressWarnings("unchecked")
	private <T> T readPropertyNullSafe(Map<String, Object> input, String... path) {
        if (path.length == 1) {
            if (input == null) {
                return null;
            }
            return (T) input.get(path[0]);
        } else if (path.length > 1) {
            Object object = input.get(path[0]);
            if (!(object instanceof Map)) {
                return null;
            }
            return readPropertyNullSafe((Map<String, Object>) object, Arrays.copyOfRange(path, 1, path.length));
        }
        return null;
    }

    private Map<String, Object> getSwaggerDocAsMap(Resource resource) {
        try {
            return objectMapper.readValue(resource.getInputStream(), new TypeReference<Map<String, Object>>() {
            });
        } catch (IOException e) {
            LOG.error("Failed to read swagger doc", e);
            throw new RuntimeException(e);
        }
    }

    static class SwaggerResource {

        private String name;
        private String url;
        private String swaggerVersion;
        private String location;

        SwaggerResource(String name, String url, String swaggerVersion, String location) {
            this.name = name;
            this.url = url;
            this.swaggerVersion = swaggerVersion;
            this.location = location;
        }

        public String getName() {
            return name;
        }

        public String getUrl() {
            return url;
        }

        public String getSwaggerVersion() {
            return swaggerVersion;
        }

        public String getLocation() {
            return location;
        }
    }

}
