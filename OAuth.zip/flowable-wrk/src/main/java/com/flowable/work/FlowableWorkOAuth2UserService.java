package com.flowable.work;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtDecoders;

public class FlowableWorkOAuth2UserService implements OAuth2UserService<OidcUserRequest, OidcUser> {

	private static final Logger log = LoggerFactory.getLogger(FlowableWorkOAuth2UserService.class);
	
	private static final String ATTRIBUTE_PREFERRED_USERNAME = "preferred_username";

    @SuppressWarnings("unchecked")
	@Override
    public OidcUser loadUser(OidcUserRequest userRequest) throws OAuth2AuthenticationException {
        // check if token has permissions to use Flowable Work
        boolean userHasPermissionsToAccessFlowableControl = true;
        
        log.info("************** FlowableWorkOAuth2UserService ************** ");
        
        log.info("************** " + userRequest.getIdToken().getEmail());
        log.info("************** " + userRequest.getIdToken().getFullName());
        
        String tokenValue = userRequest.getAccessToken().getTokenValue();
        log.info("************** " + tokenValue);  
        log.info("************** " + userRequest.getAccessToken().getScopes());
        
        if (!userHasPermissionsToAccessFlowableControl) {
            throw new OAuth2AuthenticationException(
                    new OAuth2Error("001", userRequest.getIdToken().getClaimAsString(ATTRIBUTE_PREFERRED_USERNAME) + " is not authorized", null)
            );
        }
        JwtDecoder jwtDecoder = JwtDecoders.fromOidcIssuerLocation(userRequest.getIdToken().getIssuer().toString());
        
        Jwt jwt = jwtDecoder.decode(tokenValue);
        
        //com.flowable.core.spring.security.SecurityUtils.
        //com.flowable.core.common.api.security.SecurityScope
        
        log.info("************** " + jwt.getClaimAsStringList("realm_access"));
        
        final Map<String, Object> realmAccess = (Map<String, Object>) jwt.getClaims().get("realm_access");
        List<GrantedAuthority> grantedAuthorities = ((List<String>)realmAccess.get("roles")).stream()
                .map(roleName ->  roleName) // prefix to map to a Spring Security "role"
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
        
        log.info("*********** Size **********" + grantedAuthorities.size());
        /*List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ACCESS_CONTROL));
		grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ACCESS_ADMIN));
		grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ADMIN));
		grantedAuthorities.add(new SimpleGrantedAuthority("report-api"));
		grantedAuthorities.add(new SimpleGrantedAuthority("access-report-api"));
		grantedAuthorities.add(new SimpleGrantedAuthority("reports"));
		grantedAuthorities.add(new SimpleGrantedAuthority("access-reports"));
		grantedAuthorities.add(new SimpleGrantedAuthority("case-instances"));
		grantedAuthorities.add(new SimpleGrantedAuthority("access-case-instances"));
		grantedAuthorities.add(new SimpleGrantedAuthority("process-instances"));
		grantedAuthorities.add(new SimpleGrantedAuthority("access-process-instances"));
		return new ControlOidcUser(grantedAuthorities, userRequest.getIdToken());
		*/
         
        /*
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ACCESS_CONTROL));
        grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ACCESS_ADMIN));
        grantedAuthorities.add(new SimpleGrantedAuthority(ControlPrivileges.ADMIN));
        return new DefaultOidcUser(grantedAuthorities, userRequest.getIdToken());
        */
        return new WorkOidcUser(grantedAuthorities, userRequest.getIdToken());
    }

}
