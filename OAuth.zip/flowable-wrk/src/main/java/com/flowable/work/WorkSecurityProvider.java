package com.flowable.work;
/*
import java.security.Principal;

import org.springframework.security.core.Authentication;

import com.flowable.core.common.api.security.SecurityScope;
import com.flowable.core.common.api.security.SecurityScopeProvider;
import com.flowable.core.spring.security.FlowablePrincipalSecurityScope;

public class WorkSecurityProvider implements SecurityScopeProvider {

    @Override
    public SecurityScope getSecurityScope(Principal principal) {
        if (principal instanceof Authentication) {
            return new WorkSecurityScope((Authentication) principal);
        }
        return new FlowablePrincipalSecurityScope(principal);
    }
}
*/